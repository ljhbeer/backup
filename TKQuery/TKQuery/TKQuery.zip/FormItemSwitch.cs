﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;

namespace TKQuery
{
    [System.Security.Permissions.PermissionSet(System.Security.Permissions.SecurityAction.Demand, Name = "FullTrust")]
    [System.Runtime.InteropServices.ComVisible(true)]
    public partial class FormItemSwitch : Form
    {
        public FormItemSwitch(Db.ConnDb db)
        {
            InitializeComponent();
            data = new Data();
            activezindex = -1;
            saveiddt = null;
            ZsdDt = null;
            imgpath = @"E:\Backup\Data\COOCOIMG";
            this.db = db; 
            t = @"<style type=""text/css""> 
/* 由开发人员工具生成。它可能不是原始源文件的准确表示形式。*/
body{
	font-size:[font-size]px;
}
.spy LI{
	list-style-type: none;
	text-indent: 1em;
}
.spy P{
	margin:0 auto; 
}
</style>
<div class=""spy"">
<--!item-->
</div>";
            //ReadConfig();
            try
            {                
                RefreshInit();
                db.connClose();
            }
            catch (System.Data.OleDb.OleDbException ole)
            {
                if (db != null)
                    db.connClose();
                showfiletxt(ole.ToString());
                //existdb = false;
            }
        }
        public void AddQuestion(string id)
        {
            if (id != null)
            {
                DataRow[] dr = dt.Select("id = " + id);
                DataRow[] check = sortdt.Select("id = " + id);
                Random r = new Random();
                if (dr.Count() > 0 && check.Count() == 0)
                {
                    savedt.ImportRow(dr[0]);
                    DataRow ndr = sortdt.NewRow();
                    ndr["QView"] = dr[0]["qview"];
                    ndr["TID"] = dr[0]["tid"];
                    ndr["SID"] = 10 * sortdt.Rows.Count + 10 + r.NextDouble();
                    ndr["id"] = dr[0]["id"];
                    int tid = (short)ndr["TID"];
                    if (tid == 1)
                    {
                        int nums = sortdt.Select("tid = 1").Count();
                        sortdt.Rows.InsertAt(ndr, nums);
                    }
                    else
                    {
                        sortdt.Rows.Add(ndr);
                    }
                }
            }
        }
        public void RemoveQuestion(string id)
        {
            if (id != null)
            {
                DataRow[] check = sortdt.Select("id = " + id);
                if (check.Count() > 0)
                {
                    foreach (DataRow c in check)
                        sortdt.Rows.Remove(c);
                }
                DataRow[] checksave = savedt.Select("id = " + id);
                if (checksave.Count() > 0)
                {
                    foreach (DataRow c in checksave)
                        savedt.Rows.Remove(c);
                }
            }
        }
        public void ShowPaper(string type, string id)
        {
            if (id == "" || id == null) return;
            string sql = "";
            if (type == "paper")
            {
                sql = "select top 100  '难度:'+trim(DFT) + ' 频率:' + trim(ufq)+ ' ' + trim(indate) as infozt," +
                    " question.id,question.question,question.qview,'' as cname,iif([tid]=5, 1, 2) as tid from question,questioninfo where question.id = questioninfo.id and questioninfo.pid = " + id;
            }
            else if (type == "customer")
            {
                try
                {
                    sql = "select Itemids from Customknowledges where id = " + id;
                    DataSet ds = db.query(sql);
                    string ids = ds.Tables[0].Rows[0][0].ToString();
                    sql = "select top 100  '难度:'+trim(DFT) + ' 频率:' + trim(ufq)+ ' ' + trim(indate) as infozt," +
                        " question.id,question.question,question.qview,'' as cname,iif([tid]=5, 1, 2) as tid " +
                        "from question,questioninfo where question.id = questioninfo.id and questioninfo.id in (" + ids + ") order by instr('"
                        + ids + "',question.id)";
                }
                catch (System.Data.OleDb.OleDbException ole)
                {
                    showfiletxt(ole.ToString());
                }
            }
            try
            {
                DataSet ds = db.query(sql);
                dt = ds.Tables[0];

                string html = data.ConstructItems(dt);
                webBrowser1.DocumentText = html;
            }
            catch (System.Data.OleDb.OleDbException ole)
            {
                showfiletxt(ole.ToString());
            }
        }
        public void GoPage(int beginrec, int items, int type) // type = 1 //item  2// paper
        {
            this.showfiletxt("beginrec:=" + beginrec + "  " + items + " " + type);
            if (type == 1)
            {
                string sqlcondition = " where question.id in (";
                if (saveiddt.Rows.Count < beginrec)
                {
                    this.showfiletxt("不存在该页面");
                    return;
                }
                int end = beginrec + items > saveiddt.Rows.Count ? saveiddt.Rows.Count : beginrec + items;
                for (int i = beginrec; i < end; i++)
                {
                    sqlcondition += saveiddt.Rows[i][0].ToString() + ",";
                }
                sqlcondition += ")";
                sqlcondition = sqlcondition.Replace(",)", ")");
                string sqlcol = " '难度:'+trim(DFT) + ' 频率:' + trim(ufq)+ ' ' + trim(indate) as infozt," +
                " question.id,question.question,question.qview,cname,iif([tid]=5, 1, 2) as tid, 10.1 as sid ";
                string sql = "select top " + items + sqlcol
                       + " from question,questioninfo,tpapers"
                       + sqlcondition;
                try
                {
                    DataSet ds = db.query(sql);
                    dt = ds.Tables[0];
                    string html = data.ConstructItems(ds.Tables[0]);
                    string pagehtml = data.ConstructPagelist(items, saveiddt, 500);   //最大限制500条           
                    webBrowser1.DocumentText = html.Replace("<!--pagelist-->", pagehtml);
                }
                catch (System.Data.OleDb.OleDbException ole)
                {
                    showfiletxt(ole.ToString());
                }
            }
            else if (type == 2)
            {
                db.TestConnect();
                if (beginrec == 0) beginrec = 1;
                string sqlmax = "select max(id) from (  select top  " + beginrec + " tpaperscnt.id from tpaperscnt,tpapers where tpaperscnt.id = tpapers.id order by tpaperscnt.id )";
                DataSet ds = db.query(sqlmax);
                int maxid = (short)ds.Tables[0].Rows[0][0];
                string sql = "select top " + items + " tpaperscnt.*,tpapers.cname from tpaperscnt,tpapers where tpaperscnt.id = tpapers.id and tpaperscnt.id > " + maxid + " order by tpaperscnt.id ";
                ds = db.query(sql);
                string html = data.ConstructPaperItems(ds.Tables[0]);
                sql = "select count(*) from tpaperscnt";
                ds = db.query(sql);
                db.connClose();
                string pagehtml = data.ConstructPagelist(items, ds.Tables[0], -1);  //-1不限制
                webBrowser1.DocumentText = html.Replace("<!--pagelist-->", pagehtml);
            }
        }

        private void RefreshInit()
        {
            comboBoxpages.Items.Clear();
            List<int> pages = new List<int>();
            pages.AddRange(new int[] { 10, 50, 100, 200, 400, 800 });
            foreach (int i in pages)
                comboBoxpages.Items.Add(i);
            comboBoxpages.SelectedIndex = 1;

            db.TestConnect();
            Form1.InitComboBox("select id,cname from ttx ",ref db, ref this.comboBoxtx, "cname", "id");
            Form1.InitComboBox("select id,cname from tknowledges ",ref db, ref this.comboBoxzsd, "cname", "id");
            string sql = "select top 1 * from tselect";
            DataSet ds = db.query(sql);
            sortdt = ds.Tables[0].Clone();
            dgvt.DataSource = null;
            dgvt.DataSource = sortdt;

            string sqlcol = " '难度:'+trim(DFT) + ' 频率:' + trim(ufq)+ ' ' + trim(indate) as infozt," +
                " question.id,question.question,question.qview,cname,iif([tid]=5, 1, 2) as tid, 10.1 as sid  ";
            sql = "select top 1" + sqlcol + " from question,questioninfo,tpapers";
            ds = db.query(sql);
            dt = ds.Tables[0];
            if (savedt == null)
                savedt = dt.Clone();

            sql = "select [content] from swtkconfig where cfgname = 'imgpath'";
            ds = db.query(sql);
            if (ds.Tables[0].Rows.Count > 0)
            {
                imgpath = ds.Tables[0].Rows[0]["content"].ToString();
            }

            sql = "select * from thtml ";
            ds = db.query(sql);
            data.Init(ds.Tables[0]);

            sql = "select * from customs";
            ds = db.query(sql);
            dgvz.DataSource = ds.Tables[0];
            //sql = "select count(*) from question";
            //ds = db.query(sql);
            //showfiletxt("本题库共有 " + ds.Tables[0].Rows[0][0] + " 道试题");
        }
        private void buttonQuery_Click(object sender, EventArgs e)
        {
            int items;
            string sqlcondition;
            string sqlorder;
            ConstructCondition(out items, out sqlcondition);
            ConstructCondition(out sqlorder);
            string sqlcol = " '难度:'+trim(DFT) + ' 频率:' + trim(ufq)+ ' ' + trim(indate) as infozt," +
                " question.id,question.question,question.qview,cname,iif([tid]=5, 1, 2) as tid, 10.1 as sid ";
            string sql = "select top " + items + sqlcol
                   + " from question,questioninfo,tpapers"
                   + sqlcondition + sqlorder;
            string sqlcnt = "select count(*) from question,questioninfo,tpapers "
                   + sqlcondition;
            string sqlsaveid = "select top 500 question.id from  question,questioninfo,tpapers " + sqlcondition + sqlorder;
            try
            {
                DataSet ds = db.query(sql);
                dt = ds.Tables[0];
                string html = data.ConstructItems(ds.Tables[0]);
                ds = db.query(sqlsaveid);
                saveiddt = ds.Tables[0];
                ds = db.query(sqlcnt);
                string pagehtml = data.ConstructPagelist(items, ds.Tables[0], 500);   //最大限制500条           
                webBrowser1.DocumentText = html.Replace("<!--pagelist-->", pagehtml);
            }
            catch (System.Data.OleDb.OleDbException ole)
            {
                showfiletxt(ole.ToString());
            }
        }
        private void buttonQuerPaper_Click(object sender, EventArgs e)
        {
            string sqlcondition = "";
            string keys = textBoxKeys.Text.Trim();
            if (keys != "")
            {
                string[] vkeys = keys.Split(new string[] { " ", "\t", "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
                int ii = 0;
                foreach (string k in vkeys)
                {
                    sqlcondition += " and   cname like '%" + k + "%'  ";
                    if (ii++ > 5) break;
                }
            }
            if (sqlcondition == "")
            {
                this.showfiletxt("请输入正确的关键词重新查询");
                return;
            }
            string sql = "select top 500 tpaperscnt.*,tpapers.cname from tpaperscnt,tpapers where tpaperscnt.id = tpapers.id " + sqlcondition + " order by tpapers.id desc";
            db.TestConnect();
            DataSet ds = db.query(sql);
            string html = data.ConstructPaperItems(ds.Tables[0]);
            db.connClose();
            webBrowser1.DocumentText = html.Replace("<!--pagelist-->", "");
        }
        private void buttonshowitems_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (DataRow drs in sortdt.Rows)
                {
                    DataRow[] drv = savedt.Select("id = " + drs["id"]);
                    if (drv.Count() > 0)
                        drv[0]["sid"] = drs["sid"];
                }
                savedt.DefaultView.Sort = "TID,SID ASC";
                savedt = savedt.DefaultView.ToTable();
                string html = data.ConstructItems(savedt);
                webBrowser1.DocumentText = html;
            }
            catch (System.Data.OleDb.OleDbException ole)
            {
                showfiletxt(ole.ToString());
            }
        }
        private void buttonSelect_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            foreach (DataRow dr in dt.Rows)
            {
                savedt.ImportRow(dr);
                DataRow ndr = sortdt.NewRow();
                ndr["QView"] = dr["qview"];
                ndr["TID"] = dr["tid"];
                ndr["SID"] = 10 * sortdt.Rows.Count + 10 + r.NextDouble();
                ndr["id"] = dr["id"];
                int tid = (short)ndr["TID"];
                if (tid == 1)
                {
                    int nums = sortdt.Select("tid = 1").Count();
                    sortdt.Rows.InsertAt(ndr, nums);
                }
                else
                {
                    sortdt.Rows.Add(ndr);
                }
            }
        }
        private void buttonclearitems_Click(object sender, EventArgs e)
        {
            sortdt.Rows.Clear();
            savedt.Rows.Clear();
        }
        private void buttonShowPaperlist_Click(object sender, EventArgs e)
        {
            int items = 200;
            if (comboBoxpages.SelectedIndex != -1)
            {
                items = (int)comboBoxpages.SelectedItem;
            }
            items = items < 200 ? 200 : items;
            string sql = "select top " + items + " tpaperscnt.*,tpapers.cname from tpaperscnt,tpapers where tpaperscnt.id = tpapers.id order by tpaperscnt.id";
            db.TestConnect();
            DataSet ds = db.query(sql);
            string html = data.ConstructPaperItems(ds.Tables[0]);
            sql = "select count(*) from tpaperscnt";
            ds = db.query(sql);
            db.connClose();
            string pagehtml = data.ConstructPagelist(items, ds.Tables[0], -1);  //-1不限制
            webBrowser1.DocumentText = html.Replace("<!--pagelist-->", pagehtml);
        }
        private void buttonlocalimg_Click(object sender, EventArgs e)
        {
            string html = webBrowser1.DocumentText;
            html = Convertlocalimg(html);
            webBrowser1.DocumentText = html;
        }
        private void buttonShowCustomer_Click(object sender, EventArgs e)
        {
            string sql = "select * from Customknowledges";
            db.TestConnect();
            DataSet ds = db.query(sql);
            string html = data.ConstructCustomerItems(ds.Tables[0]);
            webBrowser1.DocumentText = html;
        }
        private void buttonOutput_Click(object sender, EventArgs e)
        {
            try
            {
                string ids = "";
                foreach (DataRow drs in sortdt.Rows)
                {
                    DataRow[] drv = savedt.Select("id = " + drs["id"]);
                    if (drv.Count() > 0)
                        drv[0]["sid"] = drs["sid"];
                    ids += drs["id"].ToString() + ",";
                }

                if (ids == "") return;
                ids = ids.Substring(0, ids.Length - 1);
                savedt.DefaultView.Sort = "TID,SID ASC";
                savedt = savedt.DefaultView.ToTable();
                string html = data.ConstructOutput(savedt);

                string sql = "select id from question where id in(" + ids + ") and answer is null or id in(" + ids + ") and answer <> ''";
                DataSet ds = db.query(sql);
                if (ds.Tables[0].Rows.Count > 0)
                {//GET answer from net work
                    GetAnswerFromNetwork(ds.Tables[0]);
                }
                sql = "select id,answer from question where id in(" + ids + ") order by instr('" + ids + "',id)";
                ds = db.query(sql);
                string answer = data.ConstructOutputAnswer(ds.Tables[0]);
                //输出答案
                html = html.Replace("</body>", answer + "\r\n</body>");
                if (checkBoxoutlocalimg.Checked)
                {
                    html = Convertlocalimg(html);
                }
                File.WriteAllText("save.html", html, Encoding.UTF8);
                webBrowser1.DocumentText = html;
            }
            catch (System.Data.OleDb.OleDbException ole)
            {
                showfiletxt(ole.ToString());
            }
        }

        private void buttonAddCustom_Click(object sender, EventArgs e)
        {
            string cname = InputBox.Input("输入章节名称", "章节", "");
            if (cname == "") return;
            //cname = cname.Replace("|", "");
            string sql = "insert into customs(cname,Itemids) values('" + cname + "','')";
            db.update(sql);
            RefreshZj();
        }
        private void buttonAddZsd_Click(object sender, EventArgs e)
        {
            if (dgvz.CurrentRow.Index >= 0 && dgvz.CurrentRow.Index < dgvz.Rows.Count)
            {
                string cname = InputBox.Input("输入知识点名称", "知识点", "");
                cname = cname.Replace("|", "");
                if (cname == "") return;
                string zjid = dgvz.CurrentRow.Cells["ID"].Value.ToString();
                string sql = "update customs set Itemids = Itemids +'" + cname + "()|'  where id = " + zjid;
                db.update(sql);
                RefreshZj();
                RefreshdgvZsd();
            }
        }
        private void buttonClearZsdItems_Click(object sender, EventArgs e)
        {
            if (dgvk.CurrentRow.Index >= 0 && dgvk.CurrentRow.Index < dgvk.Rows.Count
                && dgvz.CurrentRow.Index >= 0 && dgvz.CurrentRow.Index < dgvz.Rows.Count
                )
            {
                string ids = "";
                string name = dgvk.CurrentRow.Cells["名称"].Value.ToString();
                string itemids = dgvz.CurrentRow.Cells["Itemids"].Value.ToString();
                //itemids = itemids.Replace(
                itemids = Regex.Replace(itemids, name + "\\([^|]*\\)", name + "(" + ids + ")");
                string zjid = dgvz.CurrentRow.Cells["ID"].Value.ToString();
                string sql = "update customs set Itemids = '" + itemids + "' where id = " + zjid;
                db.update(sql);
                RefreshZj();
                RefreshZsdDt();
                RefreshdgvZsd();
                ids = dgvk.CurrentRow.Cells["itemids"].Value.ToString();
                FormatIds(ref ids);
                RefreshdgvList(ids);
            }
        }
        private void buttonAddItemToZsd_Click(object sender, EventArgs e)
        {
            if (dgvk.CurrentRow.Index >= 0 && dgvk.CurrentRow.Index < dgvk.Rows.Count
                &&dgvz.CurrentRow.Index >= 0 && dgvz.CurrentRow.Index < dgvz.Rows.Count
                )
            {
                string ids = "";
                foreach (DataRow dr in sortdt.Rows)
                {
                    ids += "," + dr["ID"].ToString();
                }
                string name = dgvk.CurrentRow.Cells["名称"].Value.ToString();
                string itemids = dgvz.CurrentRow.Cells["Itemids"].Value.ToString();
                //itemids = itemids.Replace(
                itemids = Regex.Replace(itemids, name + "\\([^|]*\\)", name + "(" + ids + ")");
                string zjid = dgvz.CurrentRow.Cells["ID"].Value.ToString();
                string sql = "update customs set Itemids = '" + itemids + "' where id = " + zjid;
                db.update(sql);
                RefreshZj();
                RefreshZsdDt();
                RefreshdgvZsd();
                FormatIds(ref ids);
                RefreshdgvList(ids);
            }
            
        }        
        private void buttonhtmlitemtol_Click(object sender, EventArgs e)
        {
            if (!webBrowser1.DocumentText.StartsWith("<style type=\"text/css\"> "))
                return;
            string id = Form1.GetEqualValue(webBrowser1.DocumentText, "testitemli-", "\"");
            if (dgvk.CurrentRow!=null && dgvk.CurrentRow.Index >= 0 && dgvk.CurrentRow.Index < dgvk.Rows.Count
               && dgvz.CurrentRow.Index >= 0 && dgvz.CurrentRow.Index < dgvz.Rows.Count
               )
            {             
                string name = dgvk.CurrentRow.Cells["名称"].Value.ToString();
                string itemids = dgvz.CurrentRow.Cells["Itemids"].Value.ToString();
                string ids = Form1.GetEqualValue(itemids, name + "(", ")");

                ids += "," + id;
                if (ids.StartsWith(","))
                    ids = ids.Substring(1);
                //itemids = itemids.Replace(
                itemids = Regex.Replace(itemids, name + "\\([^|]*\\)", name + "(" + ids + ")");
                string zjid = dgvz.CurrentRow.Cells["ID"].Value.ToString();
                string sql = "update customs set Itemids = '" + itemids + "' where id = " + zjid;
                db.update(sql);
                RefreshZj();
                RefreshZsdDt();
                RefreshdgvZsd();
                FormatIds(ref ids);
                RefreshdgvList(ids);
            }

        }
        private void buttonltot_Click(object sender, EventArgs e)
        {
            if (dgvl.Rows.Count > 0 && dgvl.DataSource!=null)
            {
                webBrowser1.DocumentText = "";
                string ids = "";
                DataTable ldt = (DataTable)dgvl.DataSource;
                foreach (DataRow dr in ldt.Rows)
                {
                    ids += "," + dr["ID"].ToString();
                }
                FormatIds(ref ids);
                //dt.Rows.Clear();
             
                DataRow[] drv = ZsdDt.Select("id in (" + ids + ") ");
                //foreach (DataRow dr in drv)
                //{
                //    dt.ImportRow(dr);
                //}

                Random r = new Random();
                foreach (DataRow dr in drv)
                {
                    savedt.ImportRow(dr);
                    DataRow ndr = sortdt.NewRow();
                    ndr["QView"] = dr["qview"];
                    ndr["TID"] = dr["tid"];
                    ndr["SID"] = 10 * sortdt.Rows.Count + 10 + r.NextDouble();
                    ndr["id"] = dr["id"];
                    int tid = (short)ndr["TID"];
                    if (tid == 1)
                    {
                        int nums = sortdt.Select("tid = 1").Count();
                        sortdt.Rows.InsertAt(ndr, nums);
                    }
                    else
                    {
                        sortdt.Rows.Add(ndr);
                    }
                }
                
            }
        }
        private void dgvz_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(ZsdDt==null || (dgvz.CurrentRow.Index != -1 && dgvz.CurrentRow.Index != activezindex)){
                activezindex = dgvz.CurrentRow.Index;
                RefreshZsdDt();
                RefreshdgvZsd();
            }
        }
        private void dgvk_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvk.CurrentRow.Index >= 0 && dgvk.CurrentRow.Index < dgvk.Rows.Count)
            {
                string ids = dgvk.CurrentRow.Cells["itemids"].Value.ToString();
                FormatIds(ref ids);               
                RefreshdgvList(ids);
            }
        }
        private void dgvl_CellClick(object sender, DataGridViewCellEventArgs e)
        {           
            if (dgvl.CurrentRow.Index >= 0 && dgvl.CurrentRow.Index < dgvl.Rows.Count)
            {
                string id = dgvl.CurrentRow.Cells["id"].Value.ToString();               
                RefreshItemList(id);
            }
        }
        private void dgvt_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvt.CurrentRow.Index >= 0 && dgvt.CurrentRow.Index < dgvt.Rows.Count)
            {
                string id = dgvt.CurrentRow.Cells["id"].Value.ToString();               
                RefreshItemListDtsave(id);
            }
        }
        private void dgvk_KeyUp(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Delete)
            if(dgvk.CurrentRow!=null)
            if (dgvk.CurrentRow.Index >= 0 && dgvk.CurrentRow.Index < dgvk.Rows.Count)
            {
                string name = dgvk.CurrentRow.Cells["名称"].Value.ToString();
                string itemids = dgvz.CurrentRow.Cells["Itemids"].Value.ToString();
                //itemids = itemids.Replace(
                itemids = Regex.Replace(itemids, name + "\\([^|]*\\)", "");
                string zjid = dgvz.CurrentRow.Cells["ID"].Value.ToString();
                string sql = "update customs set Itemids = '" + itemids + "' where id = " + zjid;
                db.update(sql);
                RefreshZj();
                RefreshZsdDt();
                RefreshdgvZsd();
                
                RefreshdgvList("0");
            }
        }
        private void RefreshdgvZsd()
        {
            if (dgvz.CurrentRow.Index >= 0 && dgvz.CurrentRow.Index < dgvz.Rows.Count)
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("名称");
                dt.Columns.Add("itemids");
                string zsd = dgvz.CurrentRow.Cells["Itemids"].Value.ToString();
                string[] zsds = zsd.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                //string idss = "";
                foreach (string s in zsds)
                {
                    string[] sv = s.Split(new string[] { "(", ")" }, StringSplitOptions.RemoveEmptyEntries);
                    DataRow dr = dt.NewRow();
                    if (sv.Length == 2)
                    {
                        dr["名称"] = sv[0];
                        dr["itemids"] = sv[1];
                        //idss += sv[1];
                    }else if(sv.Length == 1)
                    {
                        dr["名称"] = sv[0];
                        dr["itemids"] = "";
                    }
                    dt.Rows.Add(dr);
                }
                dgvk.DataSource = dt;
                //SaveToZsdDt(idss);
            }
        }
        private void RefreshZsdDt()
        {
            if (dgvz.CurrentRow.Index >= 0 && dgvz.CurrentRow.Index < dgvz.Rows.Count)
            {
                string zsd = dgvz.CurrentRow.Cells["Itemids"].Value.ToString();
                string[] zsds = zsd.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                string idss = "";
                foreach (string s in zsds)
                {
                    string[] sv = s.Split(new string[] { "(", ")" }, StringSplitOptions.RemoveEmptyEntries);                  
                    if (sv.Length == 2)
                    {
                        idss += sv[1];
                    }
                }
                FormatIds(ref idss);
                SaveToZsdDt(idss);
            }
        }
        private void RefreshdgvList(string ids)
        {
            if (ZsdDt == null) return;
            DataTable dt = new DataTable();
            dt.Columns.Add("序号");
            dt.Columns.Add("预览");
            dt.Columns.Add("id");
            DataRow[] dv = ZsdDt.Select("id in (" + ids + ") ");
            int sum = 0;
            foreach (DataRow dr in dv)
            {
                sum++;
                DataRow ndr = dt.NewRow();
                ndr["序号"] = sum;
                ndr["预览"] = dr["qview"];
                ndr["id"] = dr["id"];
                dt.Rows.Add(ndr);
            }
            dgvl.DataSource = dt;
            
        }
        private void RefreshItemList(string id)
        {
            DataRow[] drv = ZsdDt.Select("id in (" + id + ") ");
            if (drv.Length == 1)
            {
                string html = data.ConstructItem(drv[0]);
                html = t.Replace("[font-size]", Fontsize.ToString()).Replace("<--!item-->", html);
                webBrowser1.DocumentText = html;               
            }            
        }

        private void RefreshItemListDtsave(string id)
        {
            DataRow[] drv = dt.Select("id in (" + id + ") ");
            if (drv.Length == 1)
            {
                string html = data.ConstructItem(drv[0]);
                html = t.Replace("[font-size]", Fontsize.ToString()).Replace("<--!item-->", html);
                webBrowser1.DocumentText = html;
            }      
        }

        private void RefreshZj()
        {
            string sql = "select * from customs";
            DataSet ds = db.query(sql);
            dgvz.DataSource = ds.Tables[0];
        }
        private void SaveToZsdDt( string ids)
        {
            if (ids == "" || ids == null) return;           
            string sql = "";         
            try
            {
                sql = "select top 100  '难度:'+trim(DFT) + ' 频率:' + trim(ufq)+ ' ' + trim(indate) as infozt," +
                    " question.id,question.question,question.qview,'' as cname,iif([tid]=5, 1, 2) as tid " +
                    "from question,questioninfo where question.id = questioninfo.id and questioninfo.id in (" + ids + ") order by instr('"
                    + ids + "',question.id)";
                DataSet ds = db.query(sql);
                ZsdDt = ds.Tables[0];
                //dgvl.DataSource = dt;
            }
            catch (System.Data.OleDb.OleDbException ole)
            {
                showfiletxt(ole.ToString());
            }
        }
        private void ShowZsd(string ids)
        {
            if(ZsdDt==null) return;
            dt.Rows.Clear();
            DataRow[] dv = ZsdDt.Select("id in (" + ids + ") ");
            foreach (DataRow dr in dv)
            {
                dt.ImportRow(dr);
            }
            string html = data.ConstructItems(dt);
            webBrowser1.DocumentText = html;
        }
        private void GetAnswerFromNetwork(DataTable dt)
        {
            int i = 0;
            bool banswerdetail = true;
            for (; i < dt.Rows.Count; i++)
            {
                if (banswerdetail)
                {
                    if (!RunIdAnswerdetail(dt.Rows[i]["id"].ToString()))
                    {
                        i--;
                        banswerdetail = false;
                    }
                }
                else
                {
                    if (!RunIdtestdetail(dt.Rows[i]["id"].ToString()))
                        break;
                }
            }

        }
        private bool RunIdAnswerdetail(string id)
        {
            string url = "http://gzsw.cooco.net.cn/answerdetail/" + id;  //test
            string html = "";
            try
            {
                html = GetHttpWebRequest(url);
                if (html == "1、所有试题都有答案，请放心组卷")
                    return false;
                string sql = "update question set answer = '" + html.Replace("'", "''") + "' where id = " + id;
                db.update(sql);
                return true;
            }
            catch
            {
                return false;
            }

        }
        private bool RunIdtestdetail(string id)
        {
            string url = "http://gzsw.cooco.net.cn/testdetail/" + id;  //test
            string html = "";
            try
            {
                html = GetHttpWebRequest(url);
                string answer = html;

                Match m1 = Regex.Match(html, "class =\"daan\" (.*)</table>  </p>(.*)<div class=\"daan\"", RegexOptions.Multiline | RegexOptions.Singleline | RegexOptions.IgnoreCase);
                if (m1.Success && m1.Groups.Count > 2)
                {
                    html = m1.Groups[2].Value.Trim();
                    if (html.StartsWith("<br/>"))
                        html = html.Substring("<br/>".Length);
                    html = html.Trim();
                    html = html.Replace("\r\n", "\r\r");
                    html = html.Substring(0, html.IndexOf("\n"));
                    html = html.Replace("\r\r", "\r\n");
                    //return false;
                }
                string sql = "update question set answer = '" + html.Replace("'", "''") + "' where id = " + id;
                db.update(sql);
                sql = "insert into answer(id,answer) values(" + id + ",'" + answer.Replace("'", "''") + "' )";
                db.update(sql);
                return true;
            }
            catch
            {
                return false;
            }

        }
        private string Convertlocalimg(string html)
        {
            List<string> ids = new List<string>();
            foreach (DataRow dr in dt.Rows)
            {
                if (html.Contains(dr["id"].ToString()))
                    ids.Add(dr["id"].ToString());
            }
            foreach (DataRow dr in savedt.Rows)
            {
                if (html.Contains(dr["id"].ToString()))
                    ids.Add(dr["id"].ToString());
            }
            if (ids.Count == 0) return html;
            string idss = "(" + ids[0];
            for (int i = 1; i < ids.Count; i++)
                idss += "," + ids[i];
            string sql = "select imgid,path from img where id in" + idss + ")";
            DataSet ds = db.query(sql);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                if (html.Contains(dr["path"].ToString()))
                {
                    string p = dr["path"].ToString();
                    string localimg = imgpath + dr["imgid"].ToString() + p.Substring(p.LastIndexOf('.'));
                    html = html.Replace(p, localimg);
                }
            }
            return html;
        }
        private string GetWebClient(string url)
        {
            string strHTML = "";
            WebClient myWebClient = new WebClient();
            Stream myStream = myWebClient.OpenRead(url);
            StreamReader sr = new StreamReader(myStream, System.Text.Encoding.GetEncoding("utf-8"));
            strHTML = sr.ReadToEnd();
            myStream.Close();
            return strHTML;
        }
        private string GetWebRequest(string url)
        {
            Uri uri = new Uri(url);
            WebRequest myReq = WebRequest.Create(uri);
            WebResponse result = myReq.GetResponse();
            Stream receviceStream = result.GetResponseStream();
            StreamReader readerOfStream = new StreamReader(receviceStream, System.Text.Encoding.GetEncoding("utf-8"));
            string strHTML = readerOfStream.ReadToEnd();
            readerOfStream.Close();
            receviceStream.Close();
            result.Close();
            return strHTML;
        }
        private string GetHttpWebRequest(string url)
        {
            Uri uri = new Uri(url);
            HttpWebRequest myReq = (HttpWebRequest)WebRequest.Create(uri);
            myReq.UserAgent = "User-Agent:Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705";
            myReq.Accept = "*/*";
            myReq.KeepAlive = true;
            myReq.Headers.Add("Accept-Language", "zh-cn,en-us;q=0.5");
            HttpWebResponse result = (HttpWebResponse)myReq.GetResponse();
            Stream receviceStream = result.GetResponseStream();
            StreamReader readerOfStream = new StreamReader(receviceStream, System.Text.Encoding.GetEncoding("utf-8"));
            string strHTML = readerOfStream.ReadToEnd();
            readerOfStream.Close();
            receviceStream.Close();
            result.Close();
            return strHTML;
        }        
        private void ConstructCondition(out string sqlorder)
        {
            int sufq = 0;
            int stime = 0;
            sqlorder = "";
            if (comboBoxSortUFQ.SelectedIndex != -1)
                sufq = comboBoxSortUFQ.SelectedIndex;
            if (comboBoxSortTime.SelectedIndex != -1)
                stime = comboBoxSortTime.SelectedIndex;
            if (sufq == 0 && stime == 0)
            {
                sqlorder = "";
            }
            else if (sufq == 0 && stime != 0)
            {
                switch (stime)
                {
                    case 1: sqlorder = "order by INDATE DESC"; break;
                    case 2: sqlorder = "order by INDATE ASC"; break;
                    case 3: sqlorder = "order by INDATE DESC"; break;
                }
            }
            else if (sufq != 0 && stime == 0)
            {
                switch (sufq)
                {
                    case 1: sqlorder = "order by UFQ DESC"; break;
                    case 2: sqlorder = "order by UFQ ASC"; break;
                }
            }
            else
            {
                switch (stime)
                {
                    case 1: sqlorder = "order by INDATE DESC"; break;
                    case 2: sqlorder = "order by INDATE ASC"; break;
                    case 3: sqlorder = "order by INDATE DESC"; break;
                }
                switch (sufq)
                {
                    case 1: sqlorder += ", UFQ DESC"; break;
                    case 2: sqlorder = ", UFQ ASC"; break;
                }
            }
        }
        private void ConstructCondition(out int items, out string sqlcondition)
        {
            int tid = 0;
            int kid = 0;
            items = 50;
            if (comboBoxtx.SelectedIndex != -1)
            {
                if (comboBoxtx.SelectedIndex != 0)
                    tid = (int)comboBoxtx.SelectedValue;
            }
            if (comboBoxzsd.SelectedIndex != -1)
            {
                if (comboBoxzsd.SelectedIndex != 0)
                    kid = (int)comboBoxzsd.SelectedIndex;
            }
            if (comboBoxpages.SelectedIndex != -1)
            {
                items = (int)comboBoxpages.SelectedItem;
            }
            string keys = textBoxKeys.Text.Trim();
            sqlcondition = " where question.id = questioninfo.id and questioninfo.pid = tpapers.id  ";
            if (tid != 0)
                sqlcondition += " and  tid = " + tid;
            if (kid != 0)
                sqlcondition += "  and kid = " + kid;

            if (keys != "")
            {
                string[] vkeys = keys.Split(new string[] { " ", "\t", "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
                int ii = 0;
                foreach (string k in vkeys)
                {
                    sqlcondition += "  and question.qview like '%" + k + "%'  ";
                    if (ii++ > 5) break;
                }

            }
        }      
        public void showfiletxt(string text)
        {
            //this.textBoxShow.Text = text;
        }
        private static void FormatIds(ref string ids)
        {
            if (ids!=null && ids.StartsWith(","))
                ids = ids.Substring(1);
            if (ids == null || ids == "")
                ids = "0";
        }
        protected override void OnLoad(EventArgs e)
        {
            webBrowser1.ObjectForScripting = this;
            base.OnLoad(e);
        }

        private Db.ConnDb db;
        private Data data;
        private DataTable dt;
        private DataTable sortdt;
        private DataTable savedt;
        private DataTable saveiddt;        
        private string imgpath;
        private DataTable ZsdDt;
        private int activezindex;
        private string t;
        private int Fontsize = 20;

       

        
    }
}
