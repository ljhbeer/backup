﻿namespace TKQuery
{
    partial class FormItemSwitch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvk = new System.Windows.Forms.DataGridView();
            this.dgvz = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dgvl = new System.Windows.Forms.DataGridView();
            this.dgvt = new System.Windows.Forms.DataGridView();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer0 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.buttonhtmlitemtol = new System.Windows.Forms.Button();
            this.buttonltot = new System.Windows.Forms.Button();
            this.buttonClearZsdItems = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonttol = new System.Windows.Forms.Button();
            this.comboBoxtx = new System.Windows.Forms.ComboBox();
            this.buttonAddZsd = new System.Windows.Forms.Button();
            this.comboBoxzsd = new System.Windows.Forms.ComboBox();
            this.buttonAddCustom = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.checkBoxoutlocalimg = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonSelect = new System.Windows.Forms.Button();
            this.buttonShowCustomer = new System.Windows.Forms.Button();
            this.buttonclearitems = new System.Windows.Forms.Button();
            this.textBoxKeys = new System.Windows.Forms.TextBox();
            this.buttonShowPaperlist = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonshowitems = new System.Windows.Forms.Button();
            this.comboBoxpages = new System.Windows.Forms.ComboBox();
            this.buttonQuerPaper = new System.Windows.Forms.Button();
            this.buttonQuery = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBoxSortUFQ = new System.Windows.Forms.ComboBox();
            this.buttonlocalimg = new System.Windows.Forms.Button();
            this.comboBoxSortTime = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.buttonOutput = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvz)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer0)).BeginInit();
            this.splitContainer0.Panel1.SuspendLayout();
            this.splitContainer0.Panel2.SuspendLayout();
            this.splitContainer0.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvk
            // 
            this.dgvk.AllowUserToAddRows = false;
            this.dgvk.AllowUserToDeleteRows = false;
            this.dgvk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvk.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvk.Location = new System.Drawing.Point(3, 17);
            this.dgvk.Name = "dgvk";
            this.dgvk.RowHeadersVisible = false;
            this.dgvk.RowTemplate.Height = 23;
            this.dgvk.Size = new System.Drawing.Size(181, 215);
            this.dgvk.TabIndex = 0;
            this.dgvk.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvk_CellClick);
            this.dgvk.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvk_KeyUp);
            // 
            // dgvz
            // 
            this.dgvz.AllowUserToAddRows = false;
            this.dgvz.AllowUserToDeleteRows = false;
            this.dgvz.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvz.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvz.Location = new System.Drawing.Point(3, 17);
            this.dgvz.Name = "dgvz";
            this.dgvz.RowHeadersVisible = false;
            this.dgvz.RowTemplate.Height = 23;
            this.dgvz.Size = new System.Drawing.Size(140, 714);
            this.dgvz.TabIndex = 0;
            this.dgvz.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvz_CellClick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgvk);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(187, 235);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "知识点";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dgvl);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(187, 495);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "试题列表";
            // 
            // dgvl
            // 
            this.dgvl.AllowUserToAddRows = false;
            this.dgvl.AllowUserToDeleteRows = false;
            this.dgvl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvl.Location = new System.Drawing.Point(3, 17);
            this.dgvl.Name = "dgvl";
            this.dgvl.RowHeadersVisible = false;
            this.dgvl.RowTemplate.Height = 23;
            this.dgvl.Size = new System.Drawing.Size(181, 475);
            this.dgvl.TabIndex = 0;
            this.dgvl.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvl_CellClick);
            // 
            // dgvt
            // 
            this.dgvt.AllowUserToAddRows = false;
            this.dgvt.AllowUserToDeleteRows = false;
            this.dgvt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvt.Location = new System.Drawing.Point(0, 0);
            this.dgvt.Name = "dgvt";
            this.dgvt.ReadOnly = true;
            this.dgvt.RowHeadersVisible = false;
            this.dgvt.RowTemplate.Height = 23;
            this.dgvt.Size = new System.Drawing.Size(331, 336);
            this.dgvt.TabIndex = 0;
            this.dgvt.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvt_CellClick);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(337, 734);
            this.splitContainer1.SplitterDistance = 146;
            this.splitContainer1.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgvz);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(146, 734);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "章节";
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.groupBox2);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.groupBox3);
            this.splitContainer2.Size = new System.Drawing.Size(187, 734);
            this.splitContainer2.SplitterDistance = 235;
            this.splitContainer2.TabIndex = 0;
            // 
            // splitContainer0
            // 
            this.splitContainer0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer0.Location = new System.Drawing.Point(0, 0);
            this.splitContainer0.Name = "splitContainer0";
            // 
            // splitContainer0.Panel1
            // 
            this.splitContainer0.Panel1.Controls.Add(this.splitContainer1);
            // 
            // splitContainer0.Panel2
            // 
            this.splitContainer0.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer0.Size = new System.Drawing.Size(1016, 734);
            this.splitContainer0.SplitterDistance = 337;
            this.splitContainer0.TabIndex = 2;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.webBrowser1);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.splitContainer4);
            this.splitContainer3.Size = new System.Drawing.Size(675, 734);
            this.splitContainer3.SplitterDistance = 394;
            this.splitContainer3.TabIndex = 0;
            // 
            // webBrowser1
            // 
            this.webBrowser1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser1.Location = new System.Drawing.Point(0, 0);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(675, 394);
            this.webBrowser1.TabIndex = 0;
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.buttonhtmlitemtol);
            this.splitContainer4.Panel1.Controls.Add(this.buttonltot);
            this.splitContainer4.Panel1.Controls.Add(this.buttonClearZsdItems);
            this.splitContainer4.Panel1.Controls.Add(this.label1);
            this.splitContainer4.Panel1.Controls.Add(this.buttonttol);
            this.splitContainer4.Panel1.Controls.Add(this.comboBoxtx);
            this.splitContainer4.Panel1.Controls.Add(this.buttonAddZsd);
            this.splitContainer4.Panel1.Controls.Add(this.comboBoxzsd);
            this.splitContainer4.Panel1.Controls.Add(this.buttonAddCustom);
            this.splitContainer4.Panel1.Controls.Add(this.label2);
            this.splitContainer4.Panel1.Controls.Add(this.checkBoxoutlocalimg);
            this.splitContainer4.Panel1.Controls.Add(this.label3);
            this.splitContainer4.Panel1.Controls.Add(this.buttonSelect);
            this.splitContainer4.Panel1.Controls.Add(this.buttonShowCustomer);
            this.splitContainer4.Panel1.Controls.Add(this.buttonclearitems);
            this.splitContainer4.Panel1.Controls.Add(this.textBoxKeys);
            this.splitContainer4.Panel1.Controls.Add(this.buttonShowPaperlist);
            this.splitContainer4.Panel1.Controls.Add(this.label4);
            this.splitContainer4.Panel1.Controls.Add(this.buttonshowitems);
            this.splitContainer4.Panel1.Controls.Add(this.comboBoxpages);
            this.splitContainer4.Panel1.Controls.Add(this.buttonQuerPaper);
            this.splitContainer4.Panel1.Controls.Add(this.buttonQuery);
            this.splitContainer4.Panel1.Controls.Add(this.label8);
            this.splitContainer4.Panel1.Controls.Add(this.comboBoxSortUFQ);
            this.splitContainer4.Panel1.Controls.Add(this.buttonlocalimg);
            this.splitContainer4.Panel1.Controls.Add(this.comboBoxSortTime);
            this.splitContainer4.Panel1.Controls.Add(this.label7);
            this.splitContainer4.Panel1.Controls.Add(this.buttonOutput);
            this.splitContainer4.Panel1.Controls.Add(this.label6);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.dgvt);
            this.splitContainer4.Size = new System.Drawing.Size(675, 336);
            this.splitContainer4.SplitterDistance = 340;
            this.splitContainer4.TabIndex = 61;
            // 
            // buttonhtmlitemtol
            // 
            this.buttonhtmlitemtol.Location = new System.Drawing.Point(220, 263);
            this.buttonhtmlitemtol.Name = "buttonhtmlitemtol";
            this.buttonhtmlitemtol.Size = new System.Drawing.Size(91, 24);
            this.buttonhtmlitemtol.TabIndex = 63;
            this.buttonhtmlitemtol.Text = "←↓";
            this.buttonhtmlitemtol.UseVisualStyleBackColor = true;
            this.buttonhtmlitemtol.Click += new System.EventHandler(this.buttonhtmlitemtol_Click);
            // 
            // buttonltot
            // 
            this.buttonltot.Location = new System.Drawing.Point(220, 309);
            this.buttonltot.Name = "buttonltot";
            this.buttonltot.Size = new System.Drawing.Size(91, 24);
            this.buttonltot.TabIndex = 62;
            this.buttonltot.Text = "→";
            this.buttonltot.UseVisualStyleBackColor = true;
            this.buttonltot.Click += new System.EventHandler(this.buttonltot_Click);
            // 
            // buttonClearZsdItems
            // 
            this.buttonClearZsdItems.Location = new System.Drawing.Point(0, 313);
            this.buttonClearZsdItems.Name = "buttonClearZsdItems";
            this.buttonClearZsdItems.Size = new System.Drawing.Size(91, 22);
            this.buttonClearZsdItems.TabIndex = 61;
            this.buttonClearZsdItems.Text = "清空本节知识点";
            this.buttonClearZsdItems.UseVisualStyleBackColor = true;
            this.buttonClearZsdItems.Click += new System.EventHandler(this.buttonClearZsdItems_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 39;
            this.label1.Text = "题型：";
            // 
            // buttonttol
            // 
            this.buttonttol.Location = new System.Drawing.Point(220, 286);
            this.buttonttol.Name = "buttonttol";
            this.buttonttol.Size = new System.Drawing.Size(91, 24);
            this.buttonttol.TabIndex = 60;
            this.buttonttol.Text = "←";
            this.buttonttol.UseVisualStyleBackColor = true;
            this.buttonttol.Click += new System.EventHandler(this.buttonAddItemToZsd_Click);
            // 
            // comboBoxtx
            // 
            this.comboBoxtx.FormattingEnabled = true;
            this.comboBoxtx.Location = new System.Drawing.Point(66, 4);
            this.comboBoxtx.Name = "comboBoxtx";
            this.comboBoxtx.Size = new System.Drawing.Size(121, 20);
            this.comboBoxtx.TabIndex = 38;
            // 
            // buttonAddZsd
            // 
            this.buttonAddZsd.Location = new System.Drawing.Point(0, 292);
            this.buttonAddZsd.Name = "buttonAddZsd";
            this.buttonAddZsd.Size = new System.Drawing.Size(91, 22);
            this.buttonAddZsd.TabIndex = 59;
            this.buttonAddZsd.Text = "添加节知识点";
            this.buttonAddZsd.UseVisualStyleBackColor = true;
            this.buttonAddZsd.Click += new System.EventHandler(this.buttonAddZsd_Click);
            // 
            // comboBoxzsd
            // 
            this.comboBoxzsd.FormattingEnabled = true;
            this.comboBoxzsd.Location = new System.Drawing.Point(66, 30);
            this.comboBoxzsd.MaxDropDownItems = 30;
            this.comboBoxzsd.Name = "comboBoxzsd";
            this.comboBoxzsd.Size = new System.Drawing.Size(121, 20);
            this.comboBoxzsd.TabIndex = 40;
            // 
            // buttonAddCustom
            // 
            this.buttonAddCustom.Location = new System.Drawing.Point(0, 271);
            this.buttonAddCustom.Name = "buttonAddCustom";
            this.buttonAddCustom.Size = new System.Drawing.Size(91, 22);
            this.buttonAddCustom.TabIndex = 58;
            this.buttonAddCustom.Text = "添加章节";
            this.buttonAddCustom.UseVisualStyleBackColor = true;
            this.buttonAddCustom.Click += new System.EventHandler(this.buttonAddCustom_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 41;
            this.label2.Text = "知识点：";
            // 
            // checkBoxoutlocalimg
            // 
            this.checkBoxoutlocalimg.AutoSize = true;
            this.checkBoxoutlocalimg.Location = new System.Drawing.Point(13, 229);
            this.checkBoxoutlocalimg.Name = "checkBoxoutlocalimg";
            this.checkBoxoutlocalimg.Size = new System.Drawing.Size(108, 16);
            this.checkBoxoutlocalimg.TabIndex = 57;
            this.checkBoxoutlocalimg.Text = "保存为本地图片";
            this.checkBoxoutlocalimg.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 42;
            this.label3.Text = "关键字：";
            // 
            // buttonSelect
            // 
            this.buttonSelect.Location = new System.Drawing.Point(193, 1);
            this.buttonSelect.Name = "buttonSelect";
            this.buttonSelect.Size = new System.Drawing.Size(63, 24);
            this.buttonSelect.TabIndex = 56;
            this.buttonSelect.Text = "全部添加";
            this.buttonSelect.UseVisualStyleBackColor = true;
            this.buttonSelect.Click += new System.EventHandler(this.buttonSelect_Click);
            // 
            // buttonShowCustomer
            // 
            this.buttonShowCustomer.Location = new System.Drawing.Point(274, 60);
            this.buttonShowCustomer.Name = "buttonShowCustomer";
            this.buttonShowCustomer.Size = new System.Drawing.Size(63, 24);
            this.buttonShowCustomer.TabIndex = 28;
            this.buttonShowCustomer.Text = "显示保存列表";
            this.buttonShowCustomer.UseVisualStyleBackColor = true;
            this.buttonShowCustomer.Click += new System.EventHandler(this.buttonShowCustomer_Click);
            // 
            // buttonclearitems
            // 
            this.buttonclearitems.Location = new System.Drawing.Point(274, 27);
            this.buttonclearitems.Name = "buttonclearitems";
            this.buttonclearitems.Size = new System.Drawing.Size(63, 24);
            this.buttonclearitems.TabIndex = 55;
            this.buttonclearitems.Text = "清空试题篮";
            this.buttonclearitems.UseVisualStyleBackColor = true;
            this.buttonclearitems.Click += new System.EventHandler(this.buttonclearitems_Click);
            // 
            // textBoxKeys
            // 
            this.textBoxKeys.Location = new System.Drawing.Point(13, 101);
            this.textBoxKeys.Multiline = true;
            this.textBoxKeys.Name = "textBoxKeys";
            this.textBoxKeys.Size = new System.Drawing.Size(173, 94);
            this.textBoxKeys.TabIndex = 43;
            // 
            // buttonShowPaperlist
            // 
            this.buttonShowPaperlist.Location = new System.Drawing.Point(193, 60);
            this.buttonShowPaperlist.Name = "buttonShowPaperlist";
            this.buttonShowPaperlist.Size = new System.Drawing.Size(63, 24);
            this.buttonShowPaperlist.TabIndex = 54;
            this.buttonShowPaperlist.Text = "显示试卷";
            this.buttonShowPaperlist.UseVisualStyleBackColor = true;
            this.buttonShowPaperlist.Click += new System.EventHandler(this.buttonShowPaperlist_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(74, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 12);
            this.label4.TabIndex = 44;
            this.label4.Text = "每页数显示：";
            // 
            // buttonshowitems
            // 
            this.buttonshowitems.Location = new System.Drawing.Point(274, 0);
            this.buttonshowitems.Name = "buttonshowitems";
            this.buttonshowitems.Size = new System.Drawing.Size(63, 24);
            this.buttonshowitems.TabIndex = 53;
            this.buttonshowitems.Text = "显示试题篮";
            this.buttonshowitems.UseVisualStyleBackColor = true;
            this.buttonshowitems.Click += new System.EventHandler(this.buttonshowitems_Click);
            // 
            // comboBoxpages
            // 
            this.comboBoxpages.FormattingEnabled = true;
            this.comboBoxpages.Location = new System.Drawing.Point(145, 77);
            this.comboBoxpages.Name = "comboBoxpages";
            this.comboBoxpages.Size = new System.Drawing.Size(41, 20);
            this.comboBoxpages.TabIndex = 45;
            // 
            // buttonQuerPaper
            // 
            this.buttonQuerPaper.Location = new System.Drawing.Point(11, 196);
            this.buttonQuerPaper.Name = "buttonQuerPaper";
            this.buttonQuerPaper.Size = new System.Drawing.Size(86, 27);
            this.buttonQuerPaper.TabIndex = 52;
            this.buttonQuerPaper.Text = "查询试卷";
            this.buttonQuerPaper.UseVisualStyleBackColor = true;
            this.buttonQuerPaper.Click += new System.EventHandler(this.buttonQuerPaper_Click);
            // 
            // buttonQuery
            // 
            this.buttonQuery.Location = new System.Drawing.Point(98, 196);
            this.buttonQuery.Name = "buttonQuery";
            this.buttonQuery.Size = new System.Drawing.Size(86, 27);
            this.buttonQuery.TabIndex = 46;
            this.buttonQuery.Text = "查询试题";
            this.buttonQuery.UseVisualStyleBackColor = true;
            this.buttonQuery.Click += new System.EventHandler(this.buttonQuery_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(116, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 51;
            this.label8.Text = "时间";
            // 
            // comboBoxSortUFQ
            // 
            this.comboBoxSortUFQ.FormattingEnabled = true;
            this.comboBoxSortUFQ.Items.AddRange(new object[] {
            "不限",
            "多→少",
            "少→多"});
            this.comboBoxSortUFQ.Location = new System.Drawing.Point(73, 56);
            this.comboBoxSortUFQ.Name = "comboBoxSortUFQ";
            this.comboBoxSortUFQ.Size = new System.Drawing.Size(41, 20);
            this.comboBoxSortUFQ.TabIndex = 47;
            // 
            // buttonlocalimg
            // 
            this.buttonlocalimg.Location = new System.Drawing.Point(193, 90);
            this.buttonlocalimg.Name = "buttonlocalimg";
            this.buttonlocalimg.Size = new System.Drawing.Size(63, 24);
            this.buttonlocalimg.TabIndex = 38;
            this.buttonlocalimg.Text = "本地图片";
            this.buttonlocalimg.UseVisualStyleBackColor = true;
            this.buttonlocalimg.Click += new System.EventHandler(this.buttonlocalimg_Click);
            // 
            // comboBoxSortTime
            // 
            this.comboBoxSortTime.FormattingEnabled = true;
            this.comboBoxSortTime.Items.AddRange(new object[] {
            "不限",
            "新→旧",
            "旧→新",
            "无→新→旧"});
            this.comboBoxSortTime.Location = new System.Drawing.Point(145, 56);
            this.comboBoxSortTime.Name = "comboBoxSortTime";
            this.comboBoxSortTime.Size = new System.Drawing.Size(41, 20);
            this.comboBoxSortTime.TabIndex = 48;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(44, 60);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 50;
            this.label7.Text = "频率";
            // 
            // buttonOutput
            // 
            this.buttonOutput.Location = new System.Drawing.Point(274, 90);
            this.buttonOutput.Name = "buttonOutput";
            this.buttonOutput.Size = new System.Drawing.Size(63, 24);
            this.buttonOutput.TabIndex = 35;
            this.buttonOutput.Text = "输出试卷";
            this.buttonOutput.UseVisualStyleBackColor = true;
            this.buttonOutput.Click += new System.EventHandler(this.buttonOutput_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 60);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 49;
            this.label6.Text = "排序";
            // 
            // FormItemSwitch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1016, 734);
            this.Controls.Add(this.splitContainer0);
            this.Name = "FormItemSwitch";
            this.Text = "FormShowItem";
            ((System.ComponentModel.ISupportInitialize)(this.dgvk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvz)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvt)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer0.Panel1.ResumeLayout(false);
            this.splitContainer0.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer0)).EndInit();
            this.splitContainer0.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel1.PerformLayout();
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvk;
        private System.Windows.Forms.DataGridView dgvz;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dgvt;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer0;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.Button buttonQuerPaper;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBoxSortTime;
        private System.Windows.Forms.ComboBox comboBoxSortUFQ;
        private System.Windows.Forms.Button buttonQuery;
        private System.Windows.Forms.ComboBox comboBoxpages;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxKeys;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxzsd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxtx;
        private System.Windows.Forms.Button buttonlocalimg;
        private System.Windows.Forms.Button buttonOutput;
        private System.Windows.Forms.Button buttonShowCustomer;
        private System.Windows.Forms.Button buttonSelect;
        private System.Windows.Forms.Button buttonclearitems;
        private System.Windows.Forms.Button buttonShowPaperlist;
        private System.Windows.Forms.Button buttonshowitems;
        private System.Windows.Forms.CheckBox checkBoxoutlocalimg;
        private System.Windows.Forms.Button buttonAddCustom;
        private System.Windows.Forms.Button buttonAddZsd;
        private System.Windows.Forms.Button buttonttol;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.DataGridView dgvl;
        private System.Windows.Forms.Button buttonClearZsdItems;
        private System.Windows.Forms.Button buttonhtmlitemtol;
        private System.Windows.Forms.Button buttonltot;

    }
}